import turtle


def solicitar_datos():
	print("¡Bienvenido al contador de cuentos infantiles!")
	nombre = input("Por favor, introduce el nombre del niño: ")
	edad = int(input("Introduce la edad del niño: "))
	print("Colores disponibles: Rojo, Azul, Verde, Amarillo, Rosa")
	color_favorito = input("Introduce el color favorito del niño: ")
	while color_favorito.capitalize() not in [
	    "Rojo", "Azul", "Verde", "Amarillo", "Rosa"
	]:
		print("Color no válido. Por favor, elige uno de los colores disponibles.")
		color_favorito = input("Introduce el color favorito del niño: ")
	return nombre, edad, color_favorito.capitalize()


def draw_background():
	
	turtle.penup()
	turtle.goto(-350, 50)
	turtle.pendown()
	turtle.color("green")
	turtle.begin_fill()
	turtle.forward(700)
	turtle.left(90)
	turtle.forward(200)
	turtle.left(90)
	turtle.forward(700)
	turtle.left(90)
	turtle.forward(200)
	turtle.left(90)
	turtle.end_fill()

 # Tamaño de la cabeza
	turtle.penup()
	turtle.goto(-150, 150)
	turtle.pendown()
	turtle.color("blue")
	turtle.begin_fill()
	turtle.circle(15) 
	turtle.end_fill()
	
# Gorra
	turtle.penup()
	turtle.goto(-150, 150)  # Inicio de la gorra
	turtle.pendown()
	turtle.color("red")
	turtle.begin_fill()
	turtle.right(-1500)
	turtle.forward(40)  # Ancho de la gorra
	turtle.left(90)
	turtle.forward(10)  # Altura de la gorra
	turtle.left(90)
	turtle.forward(-40)  # Completa el lado de la gorra
	turtle.left(90)
	turtle.forward(10)  # Completa la parte frontal de la gorra
	turtle.end_fill()

# Cuerpo
	turtle.penup()
	turtle.goto(-130, -20)
	turtle.pendown()
	turtle.color("black")
	turtle.right(180)
	turtle.forward(70)  # Longitud del cuerpo

# Brazos
	turtle.penup()
	turtle.goto(-100, -10)
	turtle.pendown()
	turtle.left(90)
	turtle.forward(30)  # Brazo izquierdo
	turtle.back(60)  # Brazo derecho

# Piernas
	turtle.penup()
	turtle.goto(-100, 125)
	turtle.pendown()
	turtle.left(45)
	turtle.forward(30)  # Pierna izquierda
	turtle.penup()
	turtle.goto(-100, -90)
	turtle.pendown()
	turtle.right(90)
	turtle.forward(30)  # Pierna derecha

	# Muestra la parte actual del cuento y las figuras asociadas.
def mostrar_parte(parte, color):
    turtle.clear()
    if parte == 1:
        draw_background(color)
    elif parte == 2:
        draw_background(color)
        draw_background()
    elif parte >= 3:
        draw_background(color)
        draw_background()


def generar_cuento(nombre, color_favorito):
	titulo = "El viaje mágico de " + nombre
	secuencias = [
	    ("Secuencia 1: El comienzo",
	     "En un lejano valle, habitaba un pequeño niño llamado " + nombre + "."),
	    ("Secuencia 2: El encuentro", "Un día, mientras jugaba en el campo, " +
	     nombre + " se encontró con un hada de color " + color_favorito + "."),
	    ("Secuencia 3: El desafío", "El hada le dijo a " + nombre +
	     " que para salvar el bosque encantado, debía encontrar la varita mágica perdida."
	     ),
	    ("Secuencia 4: La búsqueda", nombre +
	     " emprendió una emocionante aventura en busca de la varita mágica, enfrentando peligros y desafíos."
	     ),
	    ("Secuencia 5: El final feliz",
	     "Finalmente, después de muchas aventuras, " + nombre +
	     " encontró la varita mágica y salvó el bosque encantado.\nTodos celebraron su valentía y astucia."
	     )
	]

	screen = turtle.Screen()
	screen.title(titulo)
	screen.setup(width=800, height=600)
	turtle.hideturtle()
	turtle.speed(0)

	def draw_panel(title, text):
		turtle.clear()
		draw_background()  
		screen.bgcolor("sky blue")
		turtle.color("black")
		turtle.penup()
		turtle.goto(-380, 250)
		turtle.write(title, align="left", font=("Arial", 24, "bold"))
		turtle.goto(-380, -230)
		turtle.write("-" * len(title), align="left", font=("Arial", 18))
		turtle.goto(-380, -100)
		turtle.write(text, align="left", font=("Arial", 14))

	current_panel = 0
	draw_panel(*secuencias[current_panel])

	def next_panel():
		nonlocal current_panel
		if current_panel < len(secuencias) - 1:
			current_panel += 1
			draw_panel(*secuencias[current_panel])

	def previous_panel():
		nonlocal current_panel
		if current_panel > 0:
			current_panel -= 1
			draw_panel(*secuencias[current_panel])

	screen.onkey(next_panel, "Right")
	screen.onkey(previous_panel, "Left")
	screen.listen()
	turtle.done()


def main():
	nombre, edad, color_favorito = solicitar_datos()
	generar_cuento(nombre, color_favorito)


main()
